from setuptools import setup

setup(
    name="helloworld",
    version="0.1.0",
)